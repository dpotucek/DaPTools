"""
Created on Jul 23, 2025
Skript k upscalingu starych mp3 souboru

@author: David
"""

from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess
import argparse

SUPPORTED_EXTENSIONS = {".mp3", ".wav", ".flac", ".ogg", ".m4a"}
CODECS = {
    "mp3": "libmp3lame",
    "flac": "flac",
    "opus": "libopus",
    "wav": "pcm_s16le",
}
MAX_WORKERS = 8
INPUT_DIR = Path("/home/david/Music")
OUTPUT_DIR = Path("/home/david/Music/enhanced_output")

PRESET_FILTERS = {
    "music": (
        "afftdn=nf=-25,"
        "loudnorm=I=-16:TP=-1.5:LRA=11:print_format=summary,"
        "compand=attacks=0.3:decays=0.8:points=-80/-900|-50/-15|-20/-8|0/-5,"
        "equalizer=f=1000:t=q:w=1.5:g=2,"
        "equalizer=f=8000:t=q:w=1.5:g=1"
    ),
    "speech": (
        "highpass=f=120,"
        "lowpass=f=3000,"
        "loudnorm=I=-17:TP=-2:LRA=7:print_format=summary,"
        "compand=attacks=0.3:decays=0.5:points=-80/-900|-30/-12|-10/-6|0/-2"
    ),
    "podcast": (
        "afftdn,"
        "loudnorm=I=-18:TP=-1.5:LRA=9:print_format=summary,"
        "compand=attacks=0.4:decays=0.6:points=-80/-900|-35/-14|-10/-6|0/-3,"
        "equalizer=f=2500:t=q:w=2:g=2"
    )
}

def enhance_audio(input_path: Path, output_path: Path, codec: str, filters: str, bitrate: str):
    if output_path.exists():
        print(f"⏩ Přeskočeno: {output_path}")
        return
    output_path.parent.mkdir(parents=True, exist_ok=True)

    command = [
        "ffmpeg",
        "-y",
        "-i", str(input_path),
        "-af", filters,
        "-c:a", codec,
        "-b:a", bitrate,
        str(output_path)
    ]

    try:
        subprocess.run(
            command,
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        print(f"✅ Zpracováno: {output_path}")
    except subprocess.CalledProcessError as e:
        print(f"❌ Chyba při zpracování: {input_path}")
        print(f"🧪 Příkaz: {' '.join(command)}")
        print(f"💥 ffmpeg výstup:\n{e.stderr}")

def process_directory(output_format: str, filters: str, bitrate: str):
    codec = CODECS.get(output_format)
    if not codec:
        print(f"❌ Nepodporovaný formát: {output_format}")
        return

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        for path in INPUT_DIR.rglob("*"):
            if path.suffix.lower() not in SUPPORTED_EXTENSIONS:
                continue
            relative = path.relative_to(INPUT_DIR)
            new_path = OUTPUT_DIR / relative.with_suffix(f".{output_format}")
            executor.submit(enhance_audio, path, new_path, codec, filters, bitrate)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Dávkové vylepšení audia pomocí ffmpeg filtrů")
    parser.add_argument(
        "--format",
        type=str,
        default="mp3",
        help="Výstupní formát (mp3, flac, opus, wav). Výchozí: mp3"
    )
    parser.add_argument(
        "--bitrate",
        type=str,
        default="256k",
        help="Bitrate výstupu (např. 192k, 256k, 512k). Výchozí: 256k"
    )
    parser.add_argument(
        "--preset",
        type=str,
        choices=PRESET_FILTERS.keys(),
        default="music",
        help="Zvukový preset: music (🎵), speech (🎙️), podcast (📻). Výchozí: music"
    )
    parser.add_argument(
        "--filters",
        type=str,
        default=None,
        help="Vlastní ffmpeg -af filtr. Přepíše preset, pokud je zadán."
    )

    args = parser.parse_args()
    filters = args.filters if args.filters else PRESET_FILTERS[args.preset]

    print(f"🔧 Používá se preset: {args.preset}")
    print(f"🎚️ Použité filtry: {filters}\n")

    process_directory(args.format, filters, args.bitrate)
    print(f"\n✅ Vše hotovo! Výstup najdeš ve složce: {OUTPUT_DIR}/")